<?php $__env->startSection('title', $title); ?>

<?php $__env->startSection('content'); ?>
<h1><?php echo e($title); ?></h1>
<table class="table table-hover">
  <thead>
    <tr>
      <th>#</th>
      <th>Title</th>
      <th>Author</th>
      <th>Category</th>
      <th>Option</th>
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <th><?php echo e($loop->iteration); ?></th>
            <td><?php echo e($book->title); ?></td>
            <td><?php echo e($book->author); ?></td>
            <td><?php echo e($book->category); ?></td>
            <td>
                <div class="btn-group btn-group-sm" role="group" aria-label="Option">
                    <button type="button" class="btn btn-secondary" onClick="location.href='<?php echo e(route('updateform', ['id'=>$book->id])); ?>'">
                        Update
                    </button>
                    <button type="button" class="btn btn-secondary" onClick="location.href='<?php echo e(route('delete', ['id'=>$book->id])); ?>'">
                        Delete
                    </button>
                </div>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <form method="post" action="<?php echo e(route('create')); ?>">
        <tr>
            <th>#</th>
            <td><input type="text" class="form-control" name="title" placeholder="Title" required></td>
            <td><input type="text" class="form-control" name="author" placeholder="Author" required></td>
            <td><input type="text" class="form-control" name="category" placeholder="Category" required></td>
            <td>
            <?php echo e(csrf_field()); ?>

            <input type="submit" class="btn btn-secondary" value="Add New">
            </td>
        </tr>
    </form>
  </tbody>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>