<!DOCTYPE html>
<html>
    <head>
        <title><?php echo $__env->yieldContent('title'); ?></title>
        
        <!-- Referencing Bootstrap CSS that is hosted locally -->
        <?php echo e(Html::style('css/bootstrap.min.css')); ?>

    </head>
    <body>
        <div class="container">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
        
        <script src="https://code.jquery.com/jquery-1.10.2.min.js"></script>

        <!-- Referencing Bootstrap JS that is hosted locally -->
        <?php echo e(Html::script('js/bootstrap.min.js')); ?>

    </body>
</html>